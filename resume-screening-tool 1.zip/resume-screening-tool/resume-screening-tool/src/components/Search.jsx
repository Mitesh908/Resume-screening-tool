import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { TextField, Button, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, Typography } from '@mui/material';
import '../scss/Search.scss';

function Search() {
  const [yearsOfExperience, setYearsOfExperience] = useState('');
  const [skills, setSkills] = useState('');
  const [otherDetails, setOtherDetails] = useState('');
  const [filteredData, setFilteredData] = useState([]);
  const [noDataFound, setNoDataFound] = useState(false);
  const [searchPerformed, setSearchPerformed] = useState(false); 
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    const localStorageData = JSON.parse(localStorage.getItem('savedData')) || [];
    const filtered = localStorageData.filter(item =>
      item.yearsOfExperience.toString() === yearsOfExperience &&
      item.skills.toLowerCase().includes(skills.toLowerCase()) &&
      (item.resume && item.resume.toLowerCase().includes(otherDetails.toLowerCase()))
    );
    setSearchPerformed(true); 

    if (filtered.length === 0) {
      setNoDataFound(true);
      setFilteredData([]);
    } else {
      setNoDataFound(false);
      setFilteredData(filtered);
    }
  };

  const handleClose = () => {
    navigate('/');
  };

  return (
    <div>
      <form className='form' onSubmit={handleSearch}>
        <TextField
          label="Years of Experience"
          value={yearsOfExperience}
          onChange={(e) => setYearsOfExperience(e.target.value)}
        />
        <TextField
          label="Skills"
          value={skills}
          onChange={(e) => setSkills(e.target.value)}
        />
        <TextField
          label="Other Details"
          value={otherDetails}
          onChange={(e) => setOtherDetails(e.target.value)}
        />
        <Button type="submit" variant="contained">Search</Button>
        <Button type="button" variant="contained" onClick={handleClose}>Back</Button>
      </form>
      
      {searchPerformed && (
        noDataFound ? (
          <Typography variant="h6" className="no-data-message">
            No matching data found.
          </Typography>
        ) : (
          <TableContainer component={Paper}>
            <Table className='tableData'>
              <TableHead>
                <TableRow>
                  <TableCell>Resource Name</TableCell>
                  <TableCell>Skills</TableCell>
                  <TableCell>Years of Experience</TableCell>
                  <TableCell>Resume</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {filteredData.map((row, index) => (
                  <TableRow key={index}>
                    <TableCell>{row.resourceName}</TableCell>
                    <TableCell>{row.skills}</TableCell>
                    <TableCell>{row.yearsOfExperience}</TableCell>
                    <TableCell>
                      <a href={row.resume} download>Download</a>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )
      )}
    </div>
  );
}

export default Search;
