import React from 'react';
import { Link } from 'react-router-dom';
import '../scss/Navbar.scss'; 
import logoSvg from '../logo.svg';

function Navbar() {
  return (
    <nav className="navbar">
      <div className="logo">
        <Link to="/">
          <img src={logoSvg} alt="Logo" height={ 100} width={ 100 } />
        </Link>
      </div>
    </nav>
  );
}

export default Navbar;
