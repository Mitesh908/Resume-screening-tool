import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, TextField, Dialog, DialogTitle, DialogContent, DialogActions } from '@mui/material';
import '../scss/Inject.scss';

function Inject({ onDataSubmitted }) {
  const [resourceName, setResourceName] = useState('');
  const [yearsOfExperience, setYearsOfExperience] = useState('');
  const [skills, setSkills] = useState('');
  const [resume, setResume] = useState(null); 
  const [openDialog, setOpenDialog] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    const formData = {
      resourceName,
      yearsOfExperience,
      skills,
      resume: resume ? URL.createObjectURL(resume) : null 
    };

    const savedData = JSON.parse(localStorage.getItem('savedData')) || [];
    savedData.push(formData);
    localStorage.setItem('savedData', JSON.stringify(savedData));
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    navigate('/'); 
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setResume(file);
  };

  const handleClose = () => {
    navigate('/');
  };


  return (
    <div>
      <form className="inject-form" onSubmit={handleSubmit}>
        <TextField
          label="Resource Name"
          value={resourceName}
          onChange={(e) => setResourceName(e.target.value)}
          required
        />
        <TextField
          label="Years of Experience"
          type="number"
          value={yearsOfExperience}
          onChange={(e) => setYearsOfExperience(e.target.value)}
          required
        />
        <TextField
          label="Skills"
          value={skills}
          onChange={(e) => setSkills(e.target.value)}
          required
        />
        <input
          type="file"
          accept=".pdf,.doc,.docx"
          onChange={handleFileChange}
          style={{ margin: '10px 0' }}
        />
        <div className='button'>
        <Button type="submit" variant="contained">Submit</Button>
        <Button type="back" variant="contained" onClick={handleClose}> Back</Button>
        </div>
      </form>
      <Dialog open={openDialog} onClose={handleCloseDialog}>
        <DialogTitle>Data submitted successfully!</DialogTitle>
        <DialogContent>
          <p>Your data has been submitted successfully.</p>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog} variant="contained">OK</Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}

export default Inject;
