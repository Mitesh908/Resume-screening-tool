import React from 'react';
import { Link } from 'react-router-dom';
import '../scss/Home.scss';
import dataSvg from '../data.svg';



function Home() {
  return (
    <div>
      <img  src={ dataSvg }  alt="Resume Screening Tool Logo" className="resume-svg" />
      <h1 className='heading'>Resume Screening Tool</h1>
      <div className='buttons'>
      <Link to="/inject" className="Link">
        <button className="inject-button">Ingest</button>
      </Link>
      <Link to="/search" className="Link">
        <button className="search-button">Search</button>
      </Link>
      </div>
    </div>
  );
}

export default Home;
