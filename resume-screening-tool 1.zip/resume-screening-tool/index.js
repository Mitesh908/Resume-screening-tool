const express = require('express');
const app = express();
const PORT = 9095;
const fs = require('fs');
const fsPromises = fs.promises;
const path = require('path');
const mammoth = require('mammoth');

// env file
require('dotenv').config();

// Importing multer middleware for file uploads
const multer = require('multer');
const upload = multer({ dest: 'uploads/' });

// Importing schema for forms (assuming it is defined in another file)
const FormSchema = require('./schemas/form-schema');

// importing cors
const cors = require('cors');
// using json for communication
app.use(express.json());
app.use(cors());

// connect to db
const connectDB = require('./db/db_config');
connectDB;

// import embedding
const { generateEmbeddings, search } = require('./ai/generate-embeddings');

// Default route
app.get('', (req, res) => {
  res.json({ message: 'Hola!' });
});

// Route for form submit
app.post('/ingest', upload.single('resume'), async (req, res) => {
  try {
    const { name, experience, skills } = req.body;
    const resume = req.file;

    if (!resume) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const newFilePath = path.join('uploads', resume.filename + path.extname(resume.originalname));
    await fsPromises.rename(resume.path, newFilePath);

    const data = await fsPromises.readFile(newFilePath);
    const result = await mammoth.extractRawText({ buffer: data });
    const resumeContents = result.value;

    // Get embeddings for the resume content
    const embeddings = await generateEmbeddings(resumeContents.substring(0, 1000));

    // creating instance of form
    const save = new FormSchema({
      name: name,
      experience: experience,
      skills: JSON.parse(skills),
      resume: resumeContents,
      resumeEmbedding: embeddings,
      resumePath: newFilePath,
    });

    // save in db
    const saved = await save.save();

    // responding to the request with message
    return res.json({
      message: 'saved',
      id: saved._id,
    });
  } catch (err) {
    console.log(err);
    return res.json({ message: err._message });
  }
});

// Route to download resume
app.get('/download-resume/:id', async (req, res) => {
  try {
    const employee = await FormSchema.findById(req.params.id);

    if (!employee) {
      return res.status(404).json({ message: 'Employee not found' });
    }

    const filePath = employee.resumePath;
    const fileName = path.basename(filePath);

    res.setHeader('Content-Disposition', `attachment; filename=${fileName}`);
    res.setHeader('Content-Type', 'application/octet-stream');

    const fileStream = fs.createReadStream(filePath);
    fileStream.pipe(res);
  } catch (err) {
    console.error('Error in download-resume endpoint:', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

app.post('/search', async (req, res) => {
  try {
    const { experience, skillsArray, other } = req.body;

    let criteria = {};

    if (experience !== undefined && experience !== null && experience !== '') {
      criteria.experience = experience;
    }

    if (skillsArray && skillsArray.length > 0) {
      criteria.skills = { $in: skillsArray };
    }

    if (other) {
      const results = await search(other);

      const resultIds = results.map((result) => result.document._id.toString());

      criteria._id = { $in: resultIds };
    }

    const searchedEmployees = await FormSchema.find(criteria);

    const searchedEmployeeIds = searchedEmployees.map((employee) => employee._id.toString());

    const userDetails = await FormSchema.find({ _id: { $in: searchedEmployeeIds } }, { _id: 1, name: 1, experience: 1, skills: 1 });

    return res.json(userDetails);
  } catch (err) {
    console.error('Error in search endpoint:', err);
    return res.status(500).json({ message: 'Internal server error' });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server up and running on port ${PORT}`);
});