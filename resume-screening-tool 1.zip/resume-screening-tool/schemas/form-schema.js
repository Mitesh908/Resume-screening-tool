const mongoose = require('mongoose');
const { Schema } = mongoose;

const FormSchema = new Schema({
  name: {
    required: true,
    type: String
  },
  experience: {
    required: true,
    type: Number
  },
  skills: {
    required: true,
    type: [String]
  },
  resume: {
    required: true,
    type: String
  },
  resumePath: {
    required: true,
    type: String,
  },
  resumeEmbedding: [Number]
});

module.exports = mongoose.model('employees', FormSchema);
