const { GoogleGenerativeAI } = require('@google/generative-ai');
require('dotenv').config();
const FormSchema = require('../schemas/form-schema');
const cosineSimilarity = require('compute-cosine-similarity');



// Initialize Google Generative AI with your API key
const genAI = new GoogleGenerativeAI(`${process.env.GEMINI_API_KEY}`);

// Function to generate embeddings for a given text
async function generateEmbeddings(text) {
    try {
        // Get the Text Embeddings model
        const model = genAI.getGenerativeModel({ model: 'text-embedding-004' });

        // Generate embeddings for the text
        const result = await model.embedContent(text);
        const embedding = result.embedding;

        // Return the embedding values
        return embedding.values;
    } catch (error) {
        console.error('Error generating embeddings:', error);
        throw error;
    }
}



async function search(queryText) {
    try {
        // Generate embeddings for the query text
        const queryEmbeddings = await generateEmbeddings(queryText);

        // Search for documents in MongoDB using embeddings similarity
        const results = await searchEmbeddings(queryEmbeddings);

        return results.filter(result => result.similarity > 0.3);
        // return results;
    } catch (error) {
        console.error('Error searching:', error);
        throw error;
    }
}

async function findSimilarDocuments(embedding) {
    const documents = await FormSchema.aggregate([{
        "$vectorSearch": {
            "queryVector": embedding,
            "path": "resumeEmbedding",
            "numCandidates": 100,
            "limit": 5,
            "index": "default",
        }
    }]);

    console.log(documents);

    return documents;
}


async function searchEmbeddings(queryEmbeddings) {
    try {
        // Fetch all documents from the database
        const allDocuments = await FormSchema.find({});

        const results = allDocuments.map(doc => {
            const documentEmbeddings = doc.resumeEmbedding;
            const similarity = calculateCosineSimilarity(queryEmbeddings, documentEmbeddings);
            return { document: doc, similarity };
        }).filter(result => result.similarity >= 0);

        // Sort results by similarity
        results.sort((a, b) => b.similarity - a.similarity);

        return results.slice(0, 5); // Limit to top 5 results
    } catch (error) {
        console.error('Error searching:', error);
        throw error;
    }
}

function calculateCosineSimilarity(queryEmbeddings, documentEmbeddings) {
    const dotProduct = queryEmbeddings.reduce((acc, val, idx) => acc + val * documentEmbeddings[idx], 0);
    const queryEmbeddingsNorm = Math.sqrt(queryEmbeddings.reduce((acc, val) => acc + val * val, 0));
    const documentEmbeddingsNorm = Math.sqrt(documentEmbeddings.reduce((acc, val) => acc + val * val, 0));
    const cosineSimilarity = dotProduct / (queryEmbeddingsNorm * documentEmbeddingsNorm);

    return cosineSimilarity;
}


module.exports = { generateEmbeddings, search };
