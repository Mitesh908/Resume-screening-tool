export interface Skill {
    name: string,
    img?: string
}