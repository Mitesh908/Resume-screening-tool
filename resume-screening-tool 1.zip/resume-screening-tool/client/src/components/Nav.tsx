import React from 'react';
import logo from '../assets/logo.svg';

const Nav = () => {
    return (
        <div className='flex items-center justify-start shadow-md fixed w-full bg-white opacity-100'>
            <div className='h-[60px]'>
                <img className='w-full h-full object-contain' src={logo} alt="" />
            </div>
        </div>
    )
}

export default Nav