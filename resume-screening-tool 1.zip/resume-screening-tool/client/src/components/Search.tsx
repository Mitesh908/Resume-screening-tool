import React, { useState } from 'react';
import avatrSvg from '../assets/avtar.svg';
import axios from 'axios';

export interface SearchQuery {
    experience?: number;
    skillsArray?: string[];
    other?: string;
}

export interface Employee {
    _id: string;
    name: string;
    experience: number;
    skills: string[];
}

interface EmployeeListProps {
    employees: Employee[];
    downloadResume: (resumeId: string, name: string) => void;
}

const Search: React.FC = () => {
    const [experience, setExperience] = useState<string>('');
    const [skills, setSkills] = useState<string>('');
    const [other, setOther] = useState<string>('');
    const [employees, setEmployees] = useState<Employee[]>([]);

    const submit = async () => {
        const skillsArray = skills ? skills.split(',') : [];

        const data: SearchQuery = {};

        if (experience !== '') {
            data.experience = Number(experience);
        }

        if (skillsArray.length > 0) {
            data.skillsArray = skillsArray;
        }

        if (other !== '') {
            data.other = other;
        }

        if (Object.keys(data).length === 0) {
            console.log('No valid search criteria provided.');
            return;
        }

        console.log('Submitting data:', data);

        try {
            const res = await axios.post('/search', data);
            console.log('Search response:', res.data);
            setEmployees(res.data);
        } catch (error) {
            console.error('Error submitting search:', error);
        }
    };

    const downloadResume = async (resumeId: string, name: string) => {
        try {
            const response = await fetch(`http://localhost:9095/download-resume/${resumeId}`, {
                method: 'GET',
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.style.display = 'none';
            a.href = url;
            a.download = `${name}.docx`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        } catch (error) {
            console.error('Error downloading resume:', error);
        }
    };

    const EmployeeList: React.FC<EmployeeListProps> = ({ employees, downloadResume }) => (
        <div className='w-3/5'>
            {employees.length > 0 ? (
                employees.map((data) => (
                    <div
                        className='border border-gray-200 w-full flex gap-2 items-center p-2 hover:shadow-md rounded-md transition-shadow cursor-pointer m-2'
                        key={data._id}
                    >
                        <div className='h-10 w-10'>
                            <img className='h-full w-full' src={avatrSvg} alt="avatar" />
                        </div>
                        <div className='flex items-center justify-between w-full'>
                            <p>{data.name}</p>
                            <p
                                className='text-red-500'
                                onClick={() => downloadResume(data._id, data.name)}
                            >
                                Download
                            </p>
                        </div>
                    </div>
                ))
            ) : (
                <div>Loading...</div>
            )}
        </div>
    );

    return (
        <div className='pt-5'>
            <div className='flex p-5 gap-5'>
                <div className='w-2/5'>
                    <div className='flex flex-col gap-2 w-full'>
                        <input
                            className='outline-none border border-gray-400 px-2 py-1'
                            type="text"
                            placeholder='Experience'
                            value={experience}
                            onChange={(e) => setExperience(e.target.value)}
                        />
                        <input
                            className='outline-none border border-gray-400 px-2 py-1'
                            type="text"
                            placeholder='Skills'
                            value={skills}
                            onChange={(e) => setSkills(e.target.value)}
                        />
                        <textarea
                            className='outline-none border border-gray-400 px-2 py-1 resize-y'
                            placeholder='Anything else you are looking for?'
                            value={other}
                            onChange={(e) => setOther(e.target.value)}
                        ></textarea>
                        <button
                            onClick={submit}
                            className='bg-blue-500 text-white py-2 px-4'
                        >
                            Search
                        </button>
                    </div>
                </div>
                <EmployeeList employees={employees} downloadResume={downloadResume} />
            </div>
        </div>
    );
};

export default Search;
