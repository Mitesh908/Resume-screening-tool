import React, { useState } from 'react';
import skillsJson from '../assets/skills.json';


interface SkillsProps {
    onChange: (selectedSkills: string[]) => void;
}

const Skills: React.FC<SkillsProps> = ({ onChange }) => {
    const [selectedSkills, setSelectedSkills] = useState<string[]>([]);

    const toggleSkill = (skillName: string) => {
        const newSelectedSkills = selectedSkills.includes(skillName)
            ? selectedSkills.filter(skill => skill !== skillName)
            : [...selectedSkills, skillName];
        setSelectedSkills(newSelectedSkills);
        onChange(newSelectedSkills);
    };

    return (
        <div>
            <div className='flex items-center justify-center text-2xl mb-4'>
                <p>Select Skills</p>
            </div>

            <div className='flex flex-wrap gap-5'>
                {skillsJson.map((data: string, key: number) => (
                    <div key={key} className='flex items-center justify-center gap-2 p-2'>
                        <input
                            type="checkbox"
                            checked={selectedSkills.includes(data)}
                            onChange={() => toggleSkill(data)}
                        />
                        <p>{data}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Skills;
