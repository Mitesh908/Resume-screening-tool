import React, { useState } from 'react';
import backIcon from '../assets/back.svg';
import Upload from './Upload';
import Skills from './Skills';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

interface FormData {
    name: string;
    experience: string;
    skills: string[];
}

const Ingest = () => {
    const navigate = useNavigate();

    const [candidateName, setCandidateName] = useState<string>('');
    const [experience, setExperience] = useState<string>('');
    const [selectedSkills, setSelectedSkills] = useState<string[]>([]);
    const [uploadedFile, setUploadedFile] = useState<File | null>(null);

    const handleSkillsChange = (selected: string[]) => {
        setSelectedSkills(selected);
    };

    const handleFileChange = (file: File | null) => {
        setUploadedFile(file);
    };

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        if (uploadedFile) {
            const formData = new FormData();
            formData.append('name', candidateName);
            formData.append('experience', experience);
            formData.append('skills', JSON.stringify(selectedSkills));
            formData.append('resume', uploadedFile);

            try {
                const res = await axios.post('/ingest', formData, {
                    headers: {
                        'Content-Type': 'multipart/form-data'
                    }
                });
                console.log(res);
            } catch (error) {
                console.error('Error uploading file:', error);
            }
        }
    };

    return (
        <div className="p-5">
            <div className="my-2">
                <div
                    onClick={() => navigate(-1)}
                    className="flex items-center px-4 py-2 w-fit bg-blue-500 gap-2 cursor-pointer"
                >
                    <img className="h-5 w-5" src={backIcon} alt="back" />
                    <span className="text-white">back</span>
                </div>
            </div>
            <form onSubmit={handleSubmit}>
                <div className="flex flex-col gap-3">
                    <input
                        className="border border-gray-300 rounded-sm p-2 outline-none"
                        type="text"
                        placeholder="Name of candidate"
                        value={candidateName}
                        onChange={(e) => setCandidateName(e.target.value)}
                    />
                    <input
                        className="border border-gray-300 rounded-sm p-2 outline-none"
                        type="number"
                        placeholder="Experience"
                        value={experience}
                        onChange={(e) => setExperience(e.target.value)}
                    />
                    <Upload onFileChange={handleFileChange} />
                    <Skills onChange={handleSkillsChange} />
                    <div className="flex items-center justify-center my-2 rounded-md">
                        <button type="submit" className="px-4 py-2 bg-blue-500 text-white">
                            Submit
                        </button>
                    </div>
                </div>
            </form>
        </div>
    );
};

export default Ingest;