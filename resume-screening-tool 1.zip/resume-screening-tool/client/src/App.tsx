import { Route, Routes } from "react-router-dom";
import Home from "./components/Home";
import Ingest from "./components/Ingest";
import Search from "./components/Search";
import Nav from "./components/Nav";
import axios from "axios";

export default function App() {

  axios.defaults.baseURL = "http://localhost:9095"

  return (
    <>
      <Nav />
      <div className="pt-10">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/ingest" element={<Ingest />} />
          <Route path="/search" element={<Search />} />
        </Routes>
      </div>
    </>
  )
}
