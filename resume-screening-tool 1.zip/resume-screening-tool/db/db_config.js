const mongoose = require('mongoose');
require('dotenv').config();


DB_URL = `${process.env.DB_URL}`;

const connectToDB = async () => {

	try {
		const connection = await mongoose.connect(DB_URL);
		console.log(`connected to db ${connection.connection.host}`);
	} catch (err) {
		console.log(err);
		process.exit(1);
	}
}

module.exports = connectToDB();
